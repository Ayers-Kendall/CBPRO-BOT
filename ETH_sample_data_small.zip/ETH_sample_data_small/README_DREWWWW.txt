Time is time (or is it space??)

Price is price

Bid wall is price of largest quantity on bid

Bid wall scale is a ratio of the (wall quantity + quantity of the two closest prices) to wall criteria(TBD with ML, but 100 ETH in this data)

Ask wall is price of largest quantity on ask

Ask wall scale is a ratio of the (wall quantity + quantity of the two closest prices) to wall criteria(TBD with ML, but 100 ETH in this data)

Total Bid/Ask ratio is the ratio of all quantites summed from the 50 prices on the level 2 order book. (You can see a good use of this in the first few rows. There was a bid/ask of .5 and then it dropped a dollar

Volumes are self explanatory as well, but obviously broken at the moment. I will try to fix it soon